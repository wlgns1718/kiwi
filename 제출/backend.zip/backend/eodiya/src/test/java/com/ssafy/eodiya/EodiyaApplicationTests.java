package com.ssafy.eodiya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EodiyaApplicationTests {

	@Test
	void contextLoads() {
	}

}
